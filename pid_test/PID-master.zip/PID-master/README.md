Incremental PID Control
=============================
增量式PID算法C语言实现</br>
C implementation of Incremental PID Control
