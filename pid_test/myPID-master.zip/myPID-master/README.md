# myPID
位置式及增量式PID之C语言实现(IDE为VS2012)
